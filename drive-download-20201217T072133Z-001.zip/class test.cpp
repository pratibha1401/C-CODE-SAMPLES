#include<iostream>
using namespace std;
class test
{
	int a,b;
	public:
		test()
		{
			a=0;
			b=0;
		}
		void accept()
		{
			cout<<endl<<"enter two no.s: "<<endl;
			cout<<" ";
			cin>>a;
			cout<<" ";
			cin>>b;
		}
		void operator++()
		{
			a--;
			b--;
		}
		void display()
		{
			cout<<"\nA: "<<a;
			cout<<"\nB: "<<b;
		}
};
int main()
{
	test t;
	t.accept();
	cout<<"\n after decrementing: ";
	++t;
	++t;
	++t;
	t.display();
	return 0;
	
}
