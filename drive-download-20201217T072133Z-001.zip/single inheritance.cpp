#include<iostream>
using namespace std;
class princess
{
	public: 
	princess()
	{
	cout<<"Hi! I am a PRINCESS and my name is PARI :) ";
}

};

class prince : public princess
{
	public: 
	prince()
	{
		
	cout<<endl<<endl<<"HEY! BEAUTIFUL PRINCESS"<<endl<<endl<<"I am PRINCE HARRY :)";
}
};

int main()
{
	prince obj1;
	
	return 0;
}
