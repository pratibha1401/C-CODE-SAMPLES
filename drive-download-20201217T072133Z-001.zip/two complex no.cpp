#include<iostream>
using namespace std;
class complex
{
	public:
		float R1,I1,R2,I2,R,I;
		void putdetails()
		{
			cout<<"ENTER REAL PART OF 1st COMPLEX NO.: ";
			cin>>R1;
			cout<<"ENTER IMAGINARY PART OF 1st COMPLEX NO.: ";
			cin>>I1;
			cout<<endl<<"ENTER REAL PART OF 2nd COMPLEX NO.: ";
			cin>>R2;
			cout<<"ENTER IMAGINARY PART OF 2nd COMPLEX NO.: ";
			cin>>I2;
		}
		void add()
		{
			R = R1+R2;
			I = I1+I2;
		}
		void getdetails()
	
		{
			cout<<endl<<"first complex no. is: "<<R1<<"+"<<I1<<"i"<<endl;
			cout<<"second complex no. is: "<<R2<<"+"<<I2<<"i"<<endl;
			cout<<endl<<endl<<"ADDITION OF TWO COMPLEX NUMBERS IS: "<<R<<"+"<<I<<"i"<<endl;
		}
};
		int main()
		{
			complex o1;
			o1.putdetails();
		    o1.add();
		    o1.getdetails();
		    return 0;
		}
		

