#include<iostream>
using namespace std;
int main()
{
	int a,b,c;
	float d;
	cout<<"ENTER VALUE OF a : "<<endl;
	cin>>a;
	cout<<"ENETR VALUE OF b : "<<endl;
	cin>>b;
	cout<<"ENTER VALUE OF c : "<<endl;
	cin>>c;
	try
	{
		if((a-b)!=0)
		{
			d = c/(a-b);
			cout<<"RESULT IS: "<<d;
		}
		else
		{
			throw(a-b);
		}
	}
	catch(int i)
	{
		cout<<"ANSWER IS INFINITE BEACUSE (a-b) is: "<<i;
	}
	return 0;
}
