#include<iostream>
#include<iomanip>
using namespace std;
class employee
{
		char name[100];
		long number;
		public:
		
		void putdata()
		{
			cout<<endl<<"enter your employee name: ";
			cin>>name;
			cout<<"enter employee number: ";
			cin>>number;
		}
		void getdata()
		{
			cout<<endl<<setw(10)<<name<<setw(25)<<number;
	    }
	
};

int main()
{
	employee emp[100]; int i=0;
	char ch;
	while(true)
	{
		emp[i++].putdata();
		if(i<100)
		{
			cout<<"ENTER MORE? (PRESS 'Y' TO CONTINUE) ";
			cin>>ch;
			if(ch=='Y')
			continue;
		}
		break;
	}
	cout<<"\nEMPLOYEE NAME: "<<setw(25)<<"EMPLOYEE NUMBER: ";
	for(int j=0;j<i;j++)
	emp[j].getdata();
	
	return 0;
}
	

