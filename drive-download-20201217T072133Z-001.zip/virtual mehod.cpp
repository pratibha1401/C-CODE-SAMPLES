#include<iostream>
using namespace std;
class charge
{
	public:
		float c;
};
class electron: public virtual charge
{
	public:
		float e;
};
class holes: public virtual charge
{
	public:
		float h;
};
class semi: public electron,holes
{
	public:
		void get()
		{
			cout<<"enter value of charge: "<<endl;
			cin>>c;
			e=c;
			h=c;
		}
		void put()
		{
			cout<<"value of electron is: "<<"-"<<e<<endl;
			cout<<"value of holes is: "<<"+"<<h<<endl;
		}
};
int main()
{
	semi s;
	s.get();
	s.put();
	return 0;
}
