#include<iostream>
using namespace std;
class princess
{
	public: 
	princess()
	{
	cout<<"Hi! I am a PRINCESS and my name is PARI :) ";
}

};

class prince : public princess
{
	public: 
	prince()
	{
		
	cout<<endl<<endl<<"HEY! BEAUTIFUL PRINCESS"<<endl<<endl<<"I am PRINCE HARRY :)";
}
};

class love : public prince
{
	public:
		love()
		{
			cout<<endl<<endl<<"I LOVE YOU PRINCESS "<<endl;
		}
		
};

class marry
{
	public:
		marry()
		{
		cout<<endl<<endl<<"WILL YOU MARRY ME? ";

}
};

class decision
{
	public:
		int a;
		decision()
		{
			cout<<endl<<endl<<"WILL PRINCESS SAY YES OR NO? ";
			cin>>a;
		}
};

class confession : public marry, public decision
{
	public:
		confession()
		{
			cout<<endl<<endl<<endl<<"YES, I LOVE YOU 2 PRINCE";
		}
};

class marriage
{
	public:
		marriage()
		{
			cout<<endl<<endl<<"PRINCE HARRY and PRINCESS PARI your marriage is fixed om 29April."<<endl<<endl<<"CONGRATULATIONS!!!!";
		}
};

class prince1:public marriage
{
	public:
		prince1()
		{
		cout<<endl<<endl<<"PRINCE: I am so happy and excited. I can't wait to marry you my PRINCESS.";
    }
};

class princess1: public marriage,public decision
{
	public:
		princess1()
		{
			cout<<endl<<endl<<"PRINCESS: I am also very happy and excited my PRINCE.";
		}
};
int main()
{
	love obj1;
	confession obj2;
	prince1 obj3;
	princess1 obj4;
	return 0;
}
