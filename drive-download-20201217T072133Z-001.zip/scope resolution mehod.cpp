#include<iostream>
using namespace std;
class charge
{
	protected:
		void get()
		{
			cout<<"elctrons and holes contain charge. "<<endl;
		}
};
class electron:protected charge
{
	public:
		void get()
		{
			cout<<"electrons are negatively charged. "<<endl;
			
		}
};
class holes:protected charge
{
	public:
	void get()
	{
		cout<<"holes are positively charged. "<<endl;
	}
};

class semi: public electron,public holes
{
	
};
int main()
{
	
	semi s;
	
	s.electron::get();
	s.holes::get();
	
	return 0;
	
}
