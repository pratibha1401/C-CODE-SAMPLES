#include<iostream>
using namespace std;
class Time
{
int minutes,hours,a;
static int i;
public:
Time(int a)
{
this->a=hours=a;
this->a+=5;
minutes=i++;
cout<<"\nObj address : "<<this;
cout<<"\nAddress of i : "<<&i;
cout<<"\na= "<<this->a<<"\t\t"<<a;
}
~Time()
{
cout<<endl<<"\t\t"<<hours<<" : "<<minutes;
}
};
int Time ::i;
int main()
{
Time t3(10),t2(1);
return 0;
}

