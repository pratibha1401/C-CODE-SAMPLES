#include<iostream>
#include<math.h>
using namespace std;
class man
{
	public:
		void distance()
		{
			float x,y,z;
			cout<<"enter the first distance(x): ";
			cin>>x;
			cout<<endl<<"enter the second distance(y): ";
			cin>>y;
			
			z = sqrt(x*x + y*y);
			
			cout<<endl<<endl<<"The DISTANCE between Starting point and End point is: "<<z<<endl;
		}
};
int main()
{
	man obj;
	obj.distance();
	
	return 0;
}
