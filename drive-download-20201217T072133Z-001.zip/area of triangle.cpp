#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	float a,b,c,A,s;
	cout<<"enter the three sides of triangle"<<endl;
	cin>>a>>b>>c;
	
	s = (a+b+c)/2;
	
	A = sqrt(s*(s-a)*(s-b)*(s-c));
	
	cout<<"Area of triangle is: "<<A<<endl;
	
	return 0;
	
}
