#include<iostream>
using namespace std;
class rectangle
{
	private:
	float length,breadth;
	public:
		rectangle(float,float);
		float area()
		{
			return (length * breadth);
		}
		float length1()
		{
			return length;
		}
		float breadth1()
		{
			return breadth;
		}
		
	};
	
	rectangle::rectangle(float x,float y)
	{
		length=x;
		breadth=y;
	}
	
	int main()
	{
		rectangle o1 (6.8398,9.14);
		cout<<" THE LENGTH OF RECTANGLE IS: "<<o1.length1()<<endl;
		cout<<" THE BREADTH OF RECTANGLE IS: "<<o1.breadth1()<<endl<<endl<<endl;
		cout<<" AREA OF RECTANGLE IS: "<<o1.area()<<endl<<endl;
		
		return 0;
	}
