#include<iostream>
#include<math.h>
using namespace std;
class STUDENT
{
	public:
	char a[30],l[20],b[10],x[20],s[20],c[10],d[10];
	float M,P,DE,PCS,OOPS,WS,FM,CPP,pL,DEL,PCSL,TOTAL,PERCENTAGE=0;
	void DETAILS()
	{
	cout<<"ENTER YOUR FIRST NAME-- ";
	cin>>a;
	cout<<"(if there is no last name enter '.')"<<endl<<"ENTER YOUR LAST NAME-- ";
	cin>>l;
	cout<<"ENTER YOUR BRANCH-- ";
	cin>>b;
	cout<<"ENTER YOUR SPECIALISATION-- ";
	cin>>x;
	cout<<"ENTER YOUR SECTION-- ";
	cin>>s;
	cout<<"ENTER YOUR ROLL NUMBER-- ";
    cin>>c;
    cout<<"ENTER YOUR D.O.B.(DATE OF BIRTH)-- ";
	cin>>d;
	cout<<endl<<"enter your 'MATHS' marks-- ";
	cin>>M;
	cout<<"enter your 'PHYSICS' marks-- ";
	cin>>P;
	cout<<"enter your 'PHYSICS LAB' marks-- ";
	cin>>pL;
	cout<<"enter your 'DIGITAL ELECTRONICS' marks-- ";
	cin>>DE;
	cout<<"enter your 'DIGITAL ELECTRINICS LAB' marks-- ";
	cin>>DEL;
	cout<<"enter your 'COMMUNICATION SKILLS' marks-- ";
	cin>>PCS;
	cout<<"enter your 'COMMUNICATION SKILLS LAB' marks-- ";
	cin>>PCSL;
	cout<<"enter your 'OOPS' marks-- ";
	cin>>OOPS;
	cout<<"enter your 'OOPS LAB' marks-- ";
	cin>>CPP;
	cout<<"enter your 'FM of AI&ML' marks-- ";
	cin>>FM;
	cout<<"enter your 'WORKSHOP' marks-- ";
	cin>>WS;
	cout<<endl<<endl<<endl<<" FIRST NAME   "<<a<<" "<<l<<endl;
	cout<<" CLASS        "<<b<<"("<<x<<")"<<"-"<<s<<endl;
	cout<<" ROLL NUMBER  "<<c<<endl;
	cout<<" D.O.B.       "<<d<<endl<<endl<<endl;
	cout<<"------------------------------------- "<<endl<<"!SNO.SUBJECT                MARKS   !"<<endl<<"! 1. MATHS                    "<<M<<"    !"<<endl;
	cout<<"! 2. PHYSICS                  "<<P<<"    !"<<endl;
	cout<<"! 3. PHYSICS LAB              "<<pL<<"    !"<<endl;
	cout<<"! 4. DIGITAL ELECTRONICS      "<<DE<<"    !"<<endl;
	cout<<"! 5. DIGITAL ELECTRONICS LAB  "<<DEL<<"    !"<<endl;
	cout<<"! 6. COMMUNICATION SKILLS     "<<PCS<<"    !"<<endl;
	cout<<"! 7. COMMUNICATION SKILLS LAB "<<PCSL<<"    !"<<endl;
	cout<<"! 8. OOPS                     "<<OOPS<<"    !"<<endl;
	cout<<"! 9. OOPS LAB                 "<<CPP<<"    !"<<endl;
	cout<<"! 10.FM of AI&ML              "<<FM<<"    !"<<endl;
	cout<<"! 11.WORKSHOP                 "<<WS<<"    !"<<endl<<"------------------------------------- "<<endl<<endl;
	TOTAL = (M+P+pL+DE+DEL+PCS+PCSL+OOPS+CPP+FM+WS);
	cout<<"TOTAL MARKS OUT OF 1100 is = "<<TOTAL<<endl<<endl;
	PERCENTAGE = TOTAL/1100*100;
	cout<<"PERCENTAGE(%) is = "<<PERCENTAGE<<endl;
	
	}
};

int main()
{
	STUDENT PRATIBHA;
	PRATIBHA.DETAILS();
	
	return 0;
}
