#include<iostream>
using namespace std;
int main()
{
	int a,x;
	bool palak = true;
	
	cout<<"enter any positive integer: "<<endl;
	cin>>a;
	
	for( x = 2; x <= a/2; ++x )
	if( a % x == 0 )
	{
		palak = false;
		break;
	}
	
	if(palak)
		cout<<" THE INTEGER IS A PRIME NUMBER ";
	else
	    cout<<" THE INTEGER IS NOT A PRIME NUMBER ";
	    
	    return 0;
}
