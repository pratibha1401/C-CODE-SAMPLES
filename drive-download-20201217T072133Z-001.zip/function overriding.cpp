#include <bits/stdc++.h>
using namespace std;
class Parent
{
 public:
 void print()
 {
 cout << "The Parent print function was called" << endl;
 }
};
class Child : public Parent
{
 public:
 void print() // definition of a member function already present in Parent
 {
 cout << "The child print function was called" << endl;
 } };
int main() {
 //object of parent class
 Parent obj1;
 //object of child class
 Child obj2 = Child();
 // obj1 will call the print function in Parent
 obj1.print();
 // obj2 will override the print function in Parent
 // and call the print function in Child
 obj2.print();
 return 0;
} 
