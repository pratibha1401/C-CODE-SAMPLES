#include<iostream>
using namespace std;
class cube
{
	public:
		int X;
		float Y;
		void intCube(int x)
		{
			X = x*x*x;
			cout<<"cube of INTEGER no. is: "<<X<<endl<<endl;
		}
		void floatCube(float y)
		{
			
			Y = y*y*y;
			cout<<"cube of FLOAT number is: "<<Y<<endl<<endl;
		}
};
int main()
{
	cube c;
	c.intCube(2);
	c.floatCube(3.6);
	return 0;
}
