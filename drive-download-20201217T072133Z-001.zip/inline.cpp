#include<iostream>
using namespace std;
inline void palak(int i)
{
	cout<<"i read in class: ";
	cin>>i;
    cout<<"my class is: "<<i;
}

