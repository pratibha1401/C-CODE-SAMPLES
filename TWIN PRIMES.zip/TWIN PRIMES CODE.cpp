#include<iostream>
#include<conio.h>
#include<stdlib.h>
#include<iomanip>
using namespace std;
class A
{
	public:

int i,j,count,num,add=0,sin=0;
       int arr[10000];
       void get()
       {
	   
       cout<<setw(56)<<"Enter the max value upto which you want to check the Twin Primes";
       cin>>num;
   }
   void dual()
   {
   
       for(i=3;i<num;i++)
       {
              count = 0;
              for(j=2;j<i;j++)
              {
                     if(i%j == 0)
                     {
                           count++;
                     }
              }
              if(count==0)
              {
                     arr[add] = i;
                     add++;
              }
              
       }
       for(int i=0;i<168;i++)
   	{
   		cout<<"*";
	   }
	   cout<<endl;
	    for(int i=0;i<22;i++)
   	{
   		cout<<"=";
	   }
       cout<<"\n|"<<"  "<<"Twin Primes are :"<<"|"<<endl;
        for(int i=0;i<22;i++)
   	{
   		cout<<"=";
	   }
	   cout<<endl;
       for(i=1;i<add;i++)
       {
              if(arr[i] == arr[i-1] +2)
              {
                     cout<<arr[i-1]<<","<<arr[i]<<endl;
              }
              
    }
}
    void non()
    {
    	 for(int i=0;i<168;i++)
   	{
   		cout<<"*";
	   }
	   cout<<endl;
    for(i=0; i<=num; i++)
	{
		sin=0;
		for(j=2; j<i; j++)
		{
			if(i%j==0)
			{
				count++;
				break;
			}
		}
		if(count>1)
		{
			cout<<"Non twin primes are"<<" "<<i<<endl;
		}
	}
	}
    
	   };


   
   int main()
   {
   	start:
   	A o1;
   	o1.get();
   	o1.dual();
   	o1.non();
   	for(int i=0;i<168;i++)
   	{
   		cout<<"-";
	   }
   	goto start;
   	
   }


